// Sebastian Chengattu
// ID: 1210640571
// objective: using priority queues.. will be finding the
//  landing time that plane x  can wait till it can land
//
//
// Recitation-3 310 Summer
// DUE : 6/7/2020 midnight
//*******************************************************************

#include<iostream>
#include<stdio.h>

using namespace std;

//PLS - plane landing system

class PLS{
    public:
        string model;
        int minutes;
        PLS *plane;

    PLS(string mod,int time){
        model=mod;
        minutes=time;
        plane=NULL;
        }
};

// new plane will be inserted
PLS*new_Plane(PLS *root,string model,int minutes){

    PLS *temp=new PLS(model,minutes);

    if(root==NULL||root->minutes>minutes){
        temp->plane=root;
        root=temp;
        }
    else{
        PLS *p=root;
        while(p->plane!=NULL){
            if(p->plane->minutes>minutes){
            temp->plane=p->plane;
            p->plane=temp;
            break;
            }
            p=p->plane;
        }

        if(p->plane==NULL){
            p->plane=temp;
            }
        }

    return root;
}

//extraction of the shortest wait time
//lowest time is removed from the priority queue
PLS*plane_landing(PLS *root){
    if(root==NULL)
    return NULL;

    string model=root->model; //assigning the value model of the plane to model
    int minutes=root->minutes; ////assigning the value minutes of the plane to minutes

    cout<<model<<" landed "<<minutes<<" mins with its orginal landing request"<<endl;
    root=root->plane;

    return root;
}

void print(PLS *root){
    if(root==NULL)
    return;

    PLS *temp=root;
    cout<<"List of the landing requests: "<<endl<<endl;

    while(temp!=NULL){
        cout<<temp->model<<" with requested time "<<temp->minutes<<endl;
        temp=temp->plane;
        }
}

int main(){
    PLS *root=NULL;
    cout<<"\t Welcome to the Plane Landing System"<<endl<<endl;
    int exit;
    int option; // will store the option of the user input in while
    string model;
    int minutes;

    while(1){
        // main menu of selections
        cout<<"1.Make a landing request"<<endl;
        cout<<"2.Land a Plane"<<endl;
        cout<<"3.List all the landing requests"<<endl;
        cout<<"4.Exit"<<endl<<endl;
        cout<<"Select your option:";
        cin>>option;


        switch(option){
            case 1:
                cout<<"Plane Model: ";
                cin>>model;
                cout<<"Landing request: ";
                cin>>minutes;

                root=new_Plane(root,model,minutes);

                cout<<"Request Stored!"<<endl<<endl;
                break;
            case 2:
                root=plane_landing(root);
                break;
            case 3:
                print(root);
                break;
            case 4:
                exit=0;
                break;
            default:
                cout<<"Please select valid options from menu..lets try again?"<<endl;
                break;
            }

    if(exit==0)
        break;
    }
}





