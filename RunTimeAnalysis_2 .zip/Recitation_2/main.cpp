// Sebastian Chengattu
// ID: 1210640571
// "Objective  of  this  recitation  is  to  reinforce  algorithm
// design  and performance analysis (theoretically and practically)
// ideas discussed in the class and apply algorithm analysis/design
// technique in solving a new problem."
// Recitation2 310 Summer
// DUE : 5/31/2020 midnight
//*******************************************************************
/*
a) Frist, develop three C++/C methods that implement the above four sorting
   algorithms described in the book. Your code should match with the exact
   algorithms described in the book. I have provided a supplementary document
   with four sorting algorithms that you need to implement here. We will use
   these four methods in part (b) below

   1. insertion sort
   2. selection sort
   3. merge sort
   4. quick sort

   (1)
Insertion-Sort(A)
for j=2 to A.length // A.length = n
    key = A[j]
//insert A[j] into sorted sequence A[i _ j-1]
    i= j-1
    while i>0 and A[i] >key
        A[i+1] =A[i]
        i = i -1
   (2)
    Selection-Sort(A){
    for i=1 to A.length-1
        min<-i
        for j<-i+1 to A.length
        if A[i]<A[min]
        min <-j
        swap (A[min], A[i])
    }

   (3)
   Merge sort (A,p,r)           Merge(A,p,q,r)
   1 if p< r                   1   n1 = q - p +1
   2 q = [(p+r)/2]             2   n2 = r - q
   3 Merge-Sort(A,p,q)         3  let L[1..n1 + 1] and R[1.. n2 +1] be new arrays
   4 Merge-Sort(A,q+1,r)       4  for i = 1 to n1
   5 Merge(A,p,q,r)            5    L[i] = A[p + i -1 ]
                               6  for j = 1 to n2
                               7    R[j] = A[q + j]
                               8  L[n1+1] = infinity
                               9  R[n2+1] = infinity
                               10 i = 1
                               11 j = 1
                               12 for k = p to r
                               13    if L[i]<= R[j]
                               14        A[k] = L[i]
                               15        i = i + 1
                               16    else A[k] = R[j]
                               17        j = j +1
   (4)
   QUICKSORT(array A, int p, int r)
   if (p<r)
       then q<- Partion (A,p,r)
            QUICKSORT(A,p,q-1)
            QUICKSORT(A,q+1,r)


   PARTITION(array A, int p, int r)
   x <- A[r]
   i <- p-1
   for j<- p to r-1
        do if (A[j]<=x)
               then i<- i+1
                    exchange A[i]<-> A[j]
   exchange A[i+1]<->A[r]
   return i+1


  GET for all
  SPACE COMPLEXTY
  Running time
  Workout Example:
  A = {67. 53, 8, 90, 45}
*/

#include <iostream>
#include <stdlib.h>
#include <time.h>
#define MAX 1000
#define MIN 100

using namespace std;

//insertion Sort
void INSERTION_SORT(double rand_Arr[], int arr_size)
{
    // why would j = 2 ? we dont want to start from the second
    // we want to sort from the first element for it to sort properly
    //a.length = arr_size
    for(int j=1; j<arr_size; j++){
        double key = rand_Arr[j];
        int i = j-1;
        // >= has to be inorder to get the first element not 1>0
        while (i>=0 && rand_Arr[i]>key){
            rand_Arr[i+1] = rand_Arr[i];
            i = i -1; //i--
        }
        rand_Arr[i+1] = key ;
    }
}


// swapping for the Selection Sort & Quick Sort the lowest index to the next lowest modified etc
void swap(double rand_Arr[], int m_min, int i)
{
    double s_swap= rand_Arr[m_min];
    rand_Arr[m_min]=rand_Arr[i];
    rand_Arr[i]= s_swap;
}
/*
will not be implementing this code to the graphs

void SELECTION_SORT(int a[], int arr_size)
{//it can not start at 1 because the first element cant be reached
    for(int i=0; i<arr_size-1; i++){
            int m_min = i;
        for(int j= i+1; j<arr_size; j++){
           //why would you compare i? with i in the pusedo code??
            if(a[j]< a[m_min]){
                m_min= j;
            }
               // swaps the lower and places it in the first element
               swap(&a[m_min], &a[i]);
        }
    }
}
*/
// will use this for the running time
void MERGE(double rand_Arr[], int p, int q, int r) {

    double N[r];// second arrays with same size of elements
    int n1=q + 1;//n1

    // set the arr two the halves and sort the array
    while(p <= q && n1 <= r) {
        if(rand_Arr[p] <= rand_Arr[n1])
            N[p++] = rand_Arr[p++];
        else
            N[p++] = rand_Arr[n1++];
    }
    while(p<=q)
        N[p++] = rand_Arr[p++];
    while(n1 <= r) {
        N[p++] = rand_Arr[n1++];
    }
    for(int low = p; low<= r; low++) {
        rand_Arr[low] = N[low];
    }
}

void MERGE_n(double rand_Arr[], int p, int q, int r)
{
    int i;
    int j;
    int k;
    int n1= q - p + 1;
    int n2= r - q;
    // new arrays
    double L[n1]; // L [1..n1+1]
    double R[n2]; // R [1..n2+1]

    //cant be 1 0 is the first element
    // but this is coping the information of the arrays to the new arrays
    for(i=0; i<n1; i++)

        L[i]= rand_Arr[p+i];//a[p+i-1]

    for(j=0; j<n2; j++)

        R[j]=rand_Arr[q+1+j]; //arr[m+j]


    //L[n1+1]=infinity;
    //R[n2+1]=infinity;

    //1st element
    i= 0;
    j=0;
    //k=p;
    //as i continuosly used this for loop it evaded the last number 90 and a new number 16 was presented so
    // i found an other code online and when using the while function it worked perfectly fine ...
/*
    for(k=p; k<r; k++)
{
        if(L[i]<=R[j])
        {
            rand_Arr[k]=L[i];
            i= i+1;// i++
        }
        else
        {
            rand_Arr[k]=R[j];
            j=j+1; //j++
        }
}
for(i; i < n1;k++)
    {
        rand_Arr[k] = L[i];
        i++;
        //k++;
    }
for(j; j < n1;k++)
    {
        rand_Arr[k] = L[i];
        j++;
        //k++;
    }
*/

while(i<n1&&j<n2)
    {
        if (L[i]<=R[j])
        {
            rand_Arr[k]=L[i];
            i++;
        }
        else
        {
            rand_Arr[k]=R[j];
            j++;
        }
        k++;
    }
while(i<n1)
    {
        rand_Arr[k]=L[i];
        i++;
        k++;
    }
while(j<n2)
    {
        rand_Arr[k]=R[j];
        j++;
        k++;
    }
}

void MERGE_SORT(double rand_Arr[],int p, int r )
{
    if (p<r)
    {
    int q=(p+r)/2;
    // will sort the halves of the first and second
    MERGE_SORT(rand_Arr,p,q);
    MERGE_SORT(rand_Arr, q+1,r);
    MERGE(rand_Arr, p, q, r);
    }
}

//Quick sort
int PARTITION(double rand_Arr[], int p, int r)
{
    int x=rand_Arr[r];// will be our pivot
    int i=p-1;// will be our lower element

    for(int j=p ;j<r-1;j++)
     {//do
            if(rand_Arr[j]<=x){
                i++;// i=i+1
               swap(rand_Arr,i,j);
            }
     }
    swap(rand_Arr,i+1, r);
    return(i+1);
}

void QUICKSORT(double rand_Arr[], int p, int r)
{       // p is the lowest index and r is the highest index!
        if(p<r)
        {
            int q = PARTITION(rand_Arr, p, r);//this function is "partitioning having the p value in the correct place"
            QUICKSORT(rand_Arr,p,q-1);
            QUICKSORT(rand_Arr,q+1,r);
        }
}

double* rand_Set_Arr(int array_Size) {
    srand(time(NULL));
    double* rand_Arr = (double*) malloc(array_Size*sizeof(double));
    for(int i = 0; i < array_Size; i++) {
        int num = (rand()%(MAX-MIN+1) + MIN);
        rand_Arr[i] = num;
    }
    return rand_Arr;
}



//function will print the arrays in the respective orders
void print_Arr(int a[], int arr_size)
{
    for(int i=0; i<arr_size; i++){
        cout<<a[i]<<" ";
    }
}


int main()
{
    // TESTING BASED UPON NOTES

   //int A_1[] ={67, 53, 8, 90, 45}; // array given
   //int n_1 = sizeof(A_1)/sizeof(A_1[0]); // 5 which is the size of the array
   //sizeof(A) = 20 bytes
   //sizeof(A(0)) =4 bytes
    // checked and worked
    //INSERTION_SORT(A_1, n_1);
    //print_Arr(A_1,n_1);
    //SELECTION_SORT(A_1, n_1);
   //print_Arr(A_1,n_1);
   // MERGE_SORT(A_1,0,n_1-1); //(the array,first index, the last index)
   //print_Arr(A_1,n_1);
   //QUICKSORT(A_1,0,n_1-1);
   //print_Arr(A_1,n_1);

    clock_t start;
    clock_t finish;
    double total_time;
    double *rand_Arr;
    int array_Size;
    //array (n) given for us to test
    int array_N[]={1000, 10000, 25000, 50000, 100000, 150000, 200000};
   cout <<"ArraySize"<<"    InsertionSort"<<"     MergeSort"<<"     QuickSort"<<endl;

   // will execute each three algorithims
    for(int n = 0; n <=6; n++){
        array_Size = array_N[n];
        cout<<array_Size<<"            ";

        // Displaying the INSERTION_SORT
        rand_Arr = rand_Set_Arr(array_Size);
        start = clock();
        INSERTION_SORT(rand_Arr, array_Size);
        finish = clock();
        total_time = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<< total_time<<"         ";

        // Displaying the MERGE_SORT
        rand_Arr = rand_Set_Arr(array_Size);
        start = clock();
        MERGE_SORT(rand_Arr, 0, array_Size-1);
        finish = clock();
        total_time = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<total_time<<"         ";

        // Displaying the QUICK_SORT
        rand_Arr = rand_Set_Arr(array_Size);
        start = clock();
        QUICKSORT(rand_Arr, 0, array_Size-1);
        finish = clock();
        total_time = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<total_time<<"         "<< endl;
    }
}


